
from ultralytics import YOLO

if __name__ == '__main__':

    # #训练模型
    model = YOLO(r"ultralytics/cfg/models/AFENet/AFEN.yaml")
    results = model.train(data=r'ultralytics\cfg\datasets\coco128.yaml',epochs=200,workers=0,batch=12)

