All task Trainers are inherited from `BaseTrainer` class that contains the model training and optimization routine
boilerplate. You can override any function of these Trainers to suit your needs.

---

### BaseTrainer API Reference

:::ultralytics.yolo.engine.trainer.BaseTrainer